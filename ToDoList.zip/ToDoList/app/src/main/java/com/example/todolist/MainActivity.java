package com.example.todolist;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class    MainActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private TaskAdapter adapter;
    private List<TaskModel> taskList = new ArrayList<>();
    private RecyclerView recyclerView;
    private EditText editTextTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        editTextTask = findViewById(R.id.editTextTask);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadTasks();

        buttonAdd.setOnClickListener(view -> {
            String task = editTextTask.getText().toString().trim();
            if (!task.isEmpty()) {
                databaseHelper.insertTask(task);
                editTextTask.setText("");
                loadTasks();
            }
        });
    }

    private void loadTasks() {
        taskList.clear();
        Cursor cursor = databaseHelper.getAllTasks();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String task = cursor.getString(1);
            taskList.add(new TaskModel(id, task));
        }
        cursor.close();
        adapter = new TaskAdapter(taskList, taskId -> {
            databaseHelper.deleteTask(taskId);
            loadTasks();
        });
        recyclerView.setAdapter(adapter);
    }
}