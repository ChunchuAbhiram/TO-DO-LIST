package com.example.todolist;

public class TaskModel {
    private int id;
    private String taskName;

    public TaskModel(int id, String taskName) {
        this.id = id;
        this.taskName = taskName;
    }

    public int getId() {
        return id;
    }

    public String getTaskName() {
        return taskName;
    }
}
